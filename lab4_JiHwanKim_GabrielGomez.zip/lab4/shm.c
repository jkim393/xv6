#include "param.h"
#include "types.h"
#include "defs.h"
#include "x86.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "spinlock.h"

struct { //shared memory table to keep track of up to 64 pages of shared memory
  struct spinlock lock;
  struct shm_page {
    uint id; //2 programs that open the smae id get same physical page
    char *frame; //pointer to physical page
    int refcnt; //number of processes sharing this page
  } shm_pages[64];
} shm_table;

void shminit() {
  int i;
  initlock(&(shm_table.lock), "SHM lock");
  acquire(&(shm_table.lock));
  for (i = 0; i< 64; i++) {
    shm_table.shm_pages[i].id =0;
    shm_table.shm_pages[i].frame =0;
    shm_table.shm_pages[i].refcnt =0;
  }
  release(&(shm_table.lock));
}

int shm_open(int id, char **pointer) {
	int i;
	int flag=0; //set to 1 if id already exists
	struct proc *curproc = myproc();
	//char *mem;
	uint a;
	a = PGROUNDUP(curproc->sz);
	//loop through
  acquire(&(shm_table.lock));
	for(i=0; i<64; i++){
		if (shm_table.shm_pages[i].id == id){//case1: id already exists
			//memset(shm_table.shm_pages[i].frame,0,PGSIZE);
			if (mappages(curproc->pgdir, (char*)a, PGSIZE, V2P(shm_table.shm_pages[i].frame), PTE_W|PTE_U) < 0){
				cprintf("error adding page");
			}
			shm_table.shm_pages[i].refcnt = shm_table.shm_pages[i].refcnt + 1;
			*pointer=(char *)a;
			curproc->sz = a + PGSIZE;
			flag=1;
			break;
		}
	}

	if(!flag){//case 2: id not found
		for(i=0; i<64; i++){
			if (shm_table.shm_pages[i].id == 0){//empty entry
				shm_table.shm_pages[i].id = id;
				shm_table.shm_pages[i].frame = kalloc();
				shm_table.shm_pages[i].refcnt=1;
				memset(shm_table.shm_pages[i].frame,0,PGSIZE);
				if (mappages(curproc->pgdir, (char*)a, PGSIZE, V2P(shm_table.shm_pages[i].frame), PTE_W|PTE_U) < 0){
					cprintf("error");
				}
				*pointer=(char *)a;
				curproc->sz = a + PGSIZE;
				break;
			}
		}
	}
	release(&(shm_table.lock));
return 0; //added to remove compiler warning -- you should decide what to return
}


int shm_close(int id) {
//you write this too!
	int i;
	//loop through
  acquire(&(shm_table.lock));
	for(i=0; i<64; i++){
		if (shm_table.shm_pages[i].id == id){
			shm_table.shm_pages[i].refcnt = shm_table.shm_pages[i].refcnt - 1;  
			if (shm_table.shm_pages[i].refcnt == 0) { //if refcnt is 0
				//clears the shm_table
				shm_table.shm_pages[i].id = 0;
				shm_table.shm_pages[i].frame = 0;
			}
			break;
		}
	}
	release(&(shm_table.lock));

return 0; //added to remove compiler warning -- you should decide what to return
}
